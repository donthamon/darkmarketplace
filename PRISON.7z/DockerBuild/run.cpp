docker-builder -f <builder.yaml> --no-push --no-cache
registry: https://index.docker.io/v1/ username: donthamon: OGBoatbat69 email: donovan.hollingsworth@gmail.com
registry: local username: 127.0.0.1:5000

web
bitcoin